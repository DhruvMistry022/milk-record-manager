(() => {
  "use strict";
  const STORAGE_KEY = "milkManagerRecords_v1";
  const THEME_KEY = "milkManagerTheme";
  const $ = (id) => document.getElementById(id);
  const todayISO = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
  };
  const currentMonth = () => todayISO().slice(0,7);
  const money = (value) => new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",minimumFractionDigits:2,maximumFractionDigits:2}).format(Number(value)||0);
  const litres = (value) => `${(Number(value)||0).toFixed(2)} L`;
  const escapeHTML = (value) => String(value ?? "").replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
  let records = loadRecords();
  let toastTimer;
  let currentPage = "dashboard";

  function loadRecords() {
    try {
      const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
      return Array.isArray(parsed) ? parsed.filter(validRecord).sort((a,b)=>b.date.localeCompare(a.date)) : [];
    } catch { return []; }
  }
  function validRecord(r) {
    return r && typeof r.date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(r.date)
      && Number.isFinite(Number(r.morning)) && Number.isFinite(Number(r.evening))
      && Number.isFinite(Number(r.rate)) && ["paid","pending"].includes(r.status);
  }
  function saveRecords() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
  }
  function totalQty(r) { return Number(r.morning)+Number(r.evening); }
  function totalAmount(r) { return totalQty(r)*Number(r.rate); }
  function monthRecords(month) { return records.filter(r=>r.date.startsWith(month)); }
  function showToast(message) {
    const el=$("toast"); el.textContent=message; el.classList.add("show");
    clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove("show"),2600);
  }
  function formatDate(date) {
    return new Date(`${date}T00:00:00`).toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"});
  }
  function monthName(month) {
    if(!month) return "Selected month";
    const [y,m]=month.split("-").map(Number);
    return new Date(y,m-1,1).toLocaleDateString("en-IN",{month:"long",year:"numeric"});
  }
  function setMonthInputs() {
    $("dashboardMonth").value=currentMonth();
    $("recordsMonth").value=currentMonth();
    $("reportMonth").value=currentMonth();
    $("todayLabel").textContent=new Date().toLocaleDateString("en-IN",{weekday:"long",day:"numeric",month:"long",year:"numeric"}).toUpperCase();
  }
  function monthSummary(month) {
    const list=monthRecords(month);
    const qty=list.reduce((s,r)=>s+totalQty(r),0);
    const amount=list.reduce((s,r)=>s+totalAmount(r),0);
    const paid=list.filter(r=>r.status==="paid").reduce((s,r)=>s+totalAmount(r),0);
    return {list,qty,amount,paid,pending:amount-paid,days:list.length,average:list.length?qty/list.length:0};
  }
  function renderDashboard() {
    const month=$("dashboardMonth").value||currentMonth(), s=monthSummary(month);
    $("monthLitres").textContent=litres(s.qty); $("monthAmount").textContent=money(s.amount);
    $("dailyAverage").textContent=litres(s.average); $("entryCount").textContent=`${s.days} recorded ${s.days===1?"day":"days"}`;
    const today=records.find(r=>r.date===todayISO());
    $("todayLitres").textContent=litres(today?totalQty(today):0);
    $("todayAmount").textContent=`${money(today?totalAmount(today):0)} today`;
    $("pendingAmount").textContent=money(s.pending); $("paidAmount").textContent=money(s.paid);
    $("pendingShare").textContent=`${s.amount?Math.round(s.pending/s.amount*100):0}%`;
    $("paidProgress").style.width=`${s.amount?Math.min(100,s.paid/s.amount*100):0}%`;
    const recent=s.list.slice().sort((a,b)=>b.date.localeCompare(a.date)).slice(0,6);
    $("recentTableBody").innerHTML=recent.length?recent.map(r=>`<tr><td>${formatDate(r.date)}</td><td>${litres(r.morning)}</td><td>${litres(r.evening)}</td><td>${litres(totalQty(r))}</td><td>${money(totalAmount(r))}</td></tr>`).join(""):`<tr><td colspan="5" class="empty-state">No records for ${escapeHTML(monthName(month))}. Add your first record.</td></tr>`;
  }
  function renderRecords() {
    const search=$("searchInput").value.trim().toLowerCase();
    const month=$("recordsMonth").value;
    const status=$("paymentFilter").value;
    const list=records.filter(r=>(!month||r.date.startsWith(month))&& (status==="all"||r.status===status) && (!search||r.date.includes(search)||formatDate(r.date).toLowerCase().includes(search)||(r.notes||"").toLowerCase().includes(search)));
    $("recordsTableBody").innerHTML=list.length?list.map(r=>`<tr>
      <td>${formatDate(r.date)}</td><td>${litres(r.morning)}</td><td>${litres(r.evening)}</td><td>${litres(totalQty(r))}</td><td>${money(r.rate)}</td><td>${money(totalAmount(r))}</td>
      <td><span class="status ${r.status}">${r.status}</span></td>
      <td><div class="row-actions"><button class="mini-action" data-edit="${escapeHTML(r.id)}" aria-label="Edit record">Edit</button><button class="mini-action" data-delete="${escapeHTML(r.id)}" aria-label="Delete record">Delete</button></div></td>
    </tr>`).join(""):`<tr><td colspan="8" class="empty-state">No records found. Try clearing the filters or add a record.</td></tr>`;
    $("recordsCount").textContent=`${list.length} ${list.length===1?"record":"records"}`;
  }
  function renderReport() {
    const month=$("reportMonth").value||currentMonth(), s=monthSummary(month);
    $("reportPeriod").textContent=monthName(month);
    $("reportLitres").textContent=litres(s.qty); $("reportAmount").textContent=money(s.amount);
    $("reportDays").textContent=s.days; $("reportAverage").textContent=litres(s.average);
    const list=s.list.slice().sort((a,b)=>a.date.localeCompare(b.date));
    $("reportTableBody").innerHTML=list.length?list.map(r=>`<tr><td>${formatDate(r.date)}</td><td>${Number(r.morning).toFixed(2)}</td><td>${Number(r.evening).toFixed(2)}</td><td>${totalQty(r).toFixed(2)}</td><td>${money(r.rate)}</td><td>${money(totalAmount(r))}</td><td><span class="status ${r.status}">${r.status}</span></td></tr>`).join(""):`<tr><td colspan="7" class="empty-state">No records for ${escapeHTML(monthName(month))}.</td></tr>`;
    $("reportGrandTotal").textContent=`${s.qty.toFixed(2)} L · ${money(s.amount)}`;
  }
  function renderAll() { renderDashboard(); renderRecords(); renderReport(); }
  function navigate(page) {
    currentPage=page;
    document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===`${page}Page`));
    document.querySelectorAll(".nav-link").forEach(a=>a.classList.toggle("active",a.dataset.page===page));
    const titles={dashboard:"Dashboard",records:"Daily records",reports:"Monthly reports",settings:"Backup & settings"};
    $("pageTitle").textContent=titles[page]||"Dashboard";
    $("sidebar").classList.remove("open");
    if(page==="dashboard")renderDashboard(); if(page==="records")renderRecords(); if(page==="reports")renderReport();
    history.replaceState(null,"",`#${page}`);
  }
  function openModal(record=null) {
    $("recordForm").reset();
    $("editId").value=record?.id||"";
    $("modalTitle").textContent=record?"Edit milk record":"Add milk record";
    $("saveRecordButton").textContent=record?"Update record":"Save record";
    $("recordDate").value=record?.date||todayISO();
    $("morningQty").value=record?.morning??1;
    $("eveningQty").value=record?.evening??1;
    $("milkRate").value=record?.rate??60;
    $("paymentStatus").value=record?.status||"pending";
    $("recordNotes").value=record?.notes||"";
    updatePreview();
    $("recordModal").classList.add("open"); $("recordModal").setAttribute("aria-hidden","false");
    document.body.style.overflow="hidden";
    setTimeout(()=>$("recordDate").focus(),50);
  }
  function closeModal() { $("recordModal").classList.remove("open"); $("recordModal").setAttribute("aria-hidden","true"); document.body.style.overflow=""; }
  function updatePreview() {
    const morning=Math.max(0,Number($("morningQty").value)||0), evening=Math.max(0,Number($("eveningQty").value)||0), rate=Math.max(0,Number($("milkRate").value)||0);
    $("previewQty").textContent=litres(morning+evening); $("previewAmount").textContent=money((morning+evening)*rate);
  }
  function submitRecord(event) {
    event.preventDefault();
    const date=$("recordDate").value, morning=Number($("morningQty").value), evening=Number($("eveningQty").value), rate=Number($("milkRate").value), id=$("editId").value;
    if(!date){showToast("Please select a date.");return;}
    if(!Number.isFinite(morning)||!Number.isFinite(evening)||morning<0||evening<0||morning+evening<=0){showToast("Enter a milk quantity greater than zero.");return;}
    if(!Number.isFinite(rate)||rate<=0){showToast("Enter a price per litre greater than zero.");return;}
    const duplicate=records.find(r=>r.date===date&&r.id!==id);
    if(duplicate&&!confirm("A record already exists for this date. Replace it with this entry?"))return;
    const record={id:id||`${Date.now()}_${Math.random().toString(36).slice(2,8)}`,date,morning,evening,rate,status:$("paymentStatus").value,notes:$("recordNotes").value.trim()};
    if(duplicate)records=records.filter(r=>r.id!==duplicate.id);
    if(id)records=records.filter(r=>r.id!==id);
    records.push(record); records.sort((a,b)=>b.date.localeCompare(a.date));
    saveRecords(); closeModal(); renderAll(); showToast(id?"Record updated successfully.":"Milk record saved successfully.");
  }
  function deleteRecord(id) {
    const record=records.find(r=>r.id===id); if(!record)return;
    if(!confirm(`Delete the milk record for ${formatDate(record.date)}?`))return;
    records=records.filter(r=>r.id!==id); saveRecords(); renderAll(); showToast("Record deleted.");
  }
  function exportCSV(month=null) {
    const list=(month?monthRecords(month):records).slice().sort((a,b)=>a.date.localeCompare(b.date));
    if(!list.length){showToast("There are no records to export.");return;}
    const rows=[["Date","Morning milk (L)","Evening milk (L)","Total milk (L)","Price per litre (INR)","Amount (INR)","Payment status","Notes"],...list.map(r=>[r.date,Number(r.morning).toFixed(2),Number(r.evening).toFixed(2),totalQty(r).toFixed(2),Number(r.rate).toFixed(2),totalAmount(r).toFixed(2),r.status,r.notes||""])];
    const csv=rows.map(row=>row.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(",")).join("\r\n");
    downloadBlob("\uFEFF"+csv,`milk-records${month?`-${month}`:""}.csv`,"text/csv;charset=utf-8;");
    showToast("CSV file downloaded.");
  }
  function downloadBlob(content,filename,type) {
    const blob=new Blob([content],{type}),url=URL.createObjectURL(blob),a=document.createElement("a");
    a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
  }
  function backup() {
    const data={app:"Milk Record Manager",version:1,exportedAt:new Date().toISOString(),records};
    downloadBlob(JSON.stringify(data,null,2),`milk-record-backup-${todayISO()}.json`,"application/json");
    showToast("Backup downloaded.");
  }
  async function restore(file) {
    try {
      const parsed=JSON.parse(await file.text()), incoming=Array.isArray(parsed)?parsed:parsed.records;
      if(!Array.isArray(incoming))throw new Error("Invalid backup format");
      const valid=incoming.filter(validRecord).map(r=>({...r,id:String(r.id||`${Date.now()}_${Math.random()}`),morning:Number(r.morning),evening:Number(r.evening),rate:Number(r.rate),notes:String(r.notes||"")}));
      if(!valid.length)throw new Error("No valid records found in this file");
      if(!confirm(`Import ${valid.length} record(s)? Existing entries with the same date will be replaced.`))return;
      const byDate=new Map(records.map(r=>[r.date,r]));
      valid.forEach(r=>byDate.set(r.date,r));
      records=[...byDate.values()].sort((a,b)=>b.date.localeCompare(a.date));
      saveRecords();renderAll();showToast(`${valid.length} record(s) imported.`);
    } catch(err) { showToast(`Could not restore backup: ${err.message}`); }
    finally { $("restoreInput").value=""; }
  }
  function bindEvents() {
    $("recordForm").addEventListener("submit",submitRecord);
    ["morningQty","eveningQty","milkRate"].forEach(id=>$(id).addEventListener("input",updatePreview));
    ["closeModal","cancelModal"].forEach(id=>$(id).addEventListener("click",closeModal));
    $("recordModal").addEventListener("click",e=>{if(e.target===$("recordModal"))closeModal();});
    document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal();});
    ["topAddButton","addRecordButton","quickAdd"].forEach(id=>$(id).addEventListener("click",()=>openModal()));
    $("dashboardMonth").addEventListener("change",renderDashboard);
    $("recordsMonth").addEventListener("change",renderRecords);
    $("searchInput").addEventListener("input",renderRecords);
    $("paymentFilter").addEventListener("change",renderRecords);
    $("clearFilters").addEventListener("click",()=>{$("searchInput").value="";$("recordsMonth").value="";$("paymentFilter").value="all";renderRecords();});
    $("reportMonth").addEventListener("change",renderReport);
    $("printReport").addEventListener("click",()=>window.print());
    ["reportExport","settingsExport","quickExport"].forEach(id=>$(id).addEventListener("click",()=>exportCSV(id==="reportExport"?$("reportMonth").value:null)));
    $("backupButton").addEventListener("click",backup);
    $("restoreInput").addEventListener("change",e=>{if(e.target.files[0])restore(e.target.files[0]);});
    $("deleteAllButton").addEventListener("click",()=>{if(!records.length){showToast("There are no records to delete.");return;}if(confirm("Delete ALL milk records from this browser? This cannot be undone.")){records=[];saveRecords();renderAll();showToast("All records deleted.");}});
    $("themeButton").addEventListener("click",toggleTheme);
    $("menuButton").addEventListener("click",()=>$("sidebar").classList.toggle("open"));
    document.addEventListener("click",e=>{
      const edit=e.target.closest("[data-edit]"),del=e.target.closest("[data-delete]"),go=e.target.closest("[data-go]"),nav=e.target.closest("[data-page]");
      if(edit){const r=records.find(x=>x.id===edit.dataset.edit);if(r)openModal(r);}
      if(del)deleteRecord(del.dataset.delete);
      if(go)navigate(go.dataset.go);
      if(nav){e.preventDefault();navigate(nav.dataset.page);}
    });
  }
  function toggleTheme() {
    document.body.classList.toggle("dark");
    const dark=document.body.classList.contains("dark");
    localStorage.setItem(THEME_KEY,dark?"dark":"light");
    $("themeButton").textContent=dark?"☀":"☾";
  }
  function init() {
    setMonthInputs();
    if(localStorage.getItem(THEME_KEY)==="dark"){document.body.classList.add("dark");$("themeButton").textContent="☀";}
    bindEvents();renderAll();
    const initial=location.hash.replace("#","");
    if(["dashboard","records","reports","settings"].includes(initial))navigate(initial);
  }
  init();
})();